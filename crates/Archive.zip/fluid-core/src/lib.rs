//! `fluid-core` — the deployment model for the serving layer.
//!
//! Where Hive builds code, Fluid *serves* it. A [`Deployment`] is the unit a
//! user ships: some static assets plus zero or more [`FunctionConfig`]s, with
//! [`Route`]s mapping request paths to either static files or a function.
//!
//! The function config carries the knobs that make compute "Fluid": an
//! in-function `max_concurrency` (many requests per instance), `min_instances`
//! (keep-warm), `max_instances` (autoscale ceiling), and an `idle_ttl` for
//! scale-to-zero.

use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use uuid::Uuid;

#[derive(Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct DeploymentId(pub String);

impl DeploymentId {
    pub fn new() -> Self {
        DeploymentId(format!("dpl-{}", &Uuid::new_v4().simple().to_string()[..10]))
    }
    pub fn as_str(&self) -> &str {
        &self.0
    }
}
impl Default for DeploymentId {
    fn default() -> Self {
        Self::new()
    }
}
impl From<String> for DeploymentId {
    fn from(s: String) -> Self {
        DeploymentId(s)
    }
}
impl std::fmt::Display for DeploymentId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}
impl std::fmt::Debug for DeploymentId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

/// A serverless function within a deployment. The server process must listen on
/// `$PORT` and speak HTTP/1.1.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FunctionConfig {
    pub name: String,
    /// Informational: "node", "python", "go", "command", ...
    #[serde(default = "default_runtime")]
    pub runtime: String,
    /// argv to start the server, e.g. ["node", "server.js"].
    pub start_cmd: Vec<String>,
    #[serde(default)]
    pub env: BTreeMap<String, String>,
    #[serde(default = "default_memory")]
    pub memory_mib: u32,
    /// Fluid in-function concurrency: max simultaneous requests per instance.
    #[serde(default = "default_max_concurrency")]
    pub max_concurrency: u32,
    /// Keep at least this many instances warm (0 = scale fully to zero).
    #[serde(default)]
    pub min_instances: u32,
    /// Autoscaling ceiling.
    #[serde(default = "default_max_instances")]
    pub max_instances: u32,
    /// Scale an idle instance down after this many seconds with no requests.
    #[serde(default = "default_idle_ttl")]
    pub idle_ttl_secs: u64,
    /// Max wall-clock duration for a single invocation (Vercel default 300s).
    /// Exceeding it returns 504 — error isolation keeps other requests alive.
    #[serde(default = "default_max_duration")]
    pub max_duration_secs: u64,
}

fn default_runtime() -> String {
    "command".into()
}
fn default_memory() -> u32 {
    512
}
fn default_max_concurrency() -> u32 {
    10
}
fn default_max_instances() -> u32 {
    10
}
fn default_idle_ttl() -> u64 {
    30
}
fn default_max_duration() -> u64 {
    300 // Vercel Fluid default max duration (5 minutes)
}

/// What a route serves.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum RouteTarget {
    Static,
    Function(String),
}

/// A path-prefix route. Longest matching prefix wins (computed at match time).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Route {
    pub pattern: String,
    pub target: RouteTarget,
}

/// A redirect rule mapped from the framework build (Next.js `redirects()`,
/// Build Output API routes with a 3xx status). Evaluated by the gateway before
/// routing — first match wins.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Redirect {
    pub source: String,
    pub destination: String,
    #[serde(default = "default_redirect_status")]
    pub status: u16,
}
fn default_redirect_status() -> u16 {
    308
}

/// A rewrite rule (path is rewritten server-side, client URL unchanged).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Rewrite {
    pub source: String,
    pub destination: String,
}

/// Middleware / proxy (`middleware.ts` / `proxy.ts`) detected in the build. Runs
/// in the edge runtime ahead of routing; `matcher` lists the path patterns it
/// applies to.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Middleware {
    #[serde(default)]
    pub matcher: Vec<String>,
    #[serde(default = "default_edge_runtime")]
    pub runtime: String,
}
fn default_edge_runtime() -> String {
    "edge".into()
}

/// `fluid.json` — what a user writes to describe their deployment.
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct Manifest {
    pub project: String,
    /// Relative dir (within the deployment root) holding static assets.
    #[serde(default)]
    pub static_dir: Option<String>,
    #[serde(default)]
    pub functions: Vec<FunctionConfig>,
    #[serde(default)]
    pub routes: Vec<Route>,
    /// Redirects mapped from the framework build (gateway honors these).
    #[serde(default)]
    pub redirects: Vec<Redirect>,
    /// Server-side rewrites mapped from the framework build.
    #[serde(default)]
    pub rewrites: Vec<Rewrite>,
    /// Edge middleware / proxy detected in the build, if any.
    #[serde(default)]
    pub middleware: Option<Middleware>,
}

impl Manifest {
    pub fn from_json(s: &str) -> Result<Manifest, serde_json::Error> {
        serde_json::from_str(s)
    }

    pub fn function(&self, name: &str) -> Option<&FunctionConfig> {
        self.functions.iter().find(|f| f.name == name)
    }

    /// Resolve a request path to a route target using longest-prefix match.
    /// Falls back to Static if nothing matches.
    pub fn resolve(&self, path: &str) -> RouteTarget {
        let mut best: Option<&Route> = None;
        for r in &self.routes {
            if path_matches(&r.pattern, path) {
                match best {
                    Some(b) if b.pattern.len() >= r.pattern.len() => {}
                    _ => best = Some(r),
                }
            }
        }
        best.map(|r| r.target.clone()).unwrap_or(RouteTarget::Static)
    }

    /// The first matching redirect for `path`, as (location, status).
    pub fn redirect_for(&self, path: &str) -> Option<(String, u16)> {
        for r in &self.redirects {
            if rule_match(&r.source, path) {
                return Some((rule_target(&r.source, &r.destination, path), r.status));
            }
        }
        None
    }

    /// Apply the first matching rewrite, returning the (possibly) rewritten path.
    pub fn rewrite_path(&self, path: &str) -> String {
        for r in &self.rewrites {
            if rule_match(&r.source, path) {
                return rule_target(&r.source, &r.destination, path);
            }
        }
        path.to_string()
    }

    /// Count of edge-runtime functions in this deployment.
    pub fn edge_function_count(&self) -> usize {
        self.functions.iter().filter(|f| f.runtime == "edge").count()
    }
}

/// Exact match, or prefix match when `source` ends with `/`.
fn rule_match(source: &str, path: &str) -> bool {
    if let Some(prefix) = source.strip_suffix('/') {
        path == prefix || path.starts_with(source)
    } else {
        path == source
    }
}

/// Build a redirect/rewrite target, preserving the remainder for prefix sources.
fn rule_target(source: &str, destination: &str, path: &str) -> String {
    if let Some(prefix) = source.strip_suffix('/') {
        if let Some(rest) = path.strip_prefix(prefix) {
            let dest = destination.trim_end_matches('/');
            return format!("{dest}{rest}");
        }
    }
    destination.to_string()
}

/// Prefix match with `/` boundary awareness. `"/api"` matches `/api` and
/// `/api/x` but not `/apixyz`. `"/"` matches everything.
pub fn path_matches(pattern: &str, path: &str) -> bool {
    if pattern == "/" {
        return true;
    }
    let pattern = pattern.trim_end_matches('/');
    if let Some(rest) = path.strip_prefix(pattern) {
        rest.is_empty() || rest.starts_with('/')
    } else {
        false
    }
}

/// Git provenance for a deployment (shown Vercel-style in the dashboard).
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct GitSource {
    pub repo_url: String,
    pub branch: String,
    pub commit: String,
    pub commit_message: String,
}

/// Lifecycle state of a deployment.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum DeployState {
    Queued,
    Building,
    Ready,
    Error,
}
impl Default for DeployState {
    fn default() -> Self { DeployState::Ready }
}

/// Serializable snapshot of a deployment (for persistence + restore).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DeployRecord {
    pub id: String,
    pub project: String,
    pub root: String,
    pub manifest: Manifest,
    pub created_at_ms: u64,
    pub creator: String,
    pub git: Option<GitSource>,
    pub production: bool,
    /// Environment the deployment was built for: "production" | "preview".
    /// Immutable; `production` only reflects whether it currently holds the prod
    /// alias. Defaults to empty (derive from `production`) for old snapshots.
    #[serde(default)]
    pub target: String,
    /// Final lifecycle state (so a failed build stays "error" across restarts).
    /// Defaults to `ready` for back-compat with snapshots written before this field.
    #[serde(default)]
    pub state: DeployState,
}

/// A registered deployment (manifest + where its files live).
#[derive(Clone, Debug)]
pub struct Deployment {
    pub id: DeploymentId,
    pub project: String,
    /// Host path to deployment files (mock backend serves from here).
    pub root: std::path::PathBuf,
    pub manifest: Manifest,
    pub created_at_ms: u64,
    pub state: DeployState,
    pub creator: String,
    pub git: Option<GitSource>,
    /// Whether this deployment currently holds the project's PRODUCTION alias
    /// (Vercel's "promoted" flag). Flips on promote/rollback — it does NOT change
    /// `target`.
    pub production: bool,
    /// The environment the deployment was BUILT for: "production" | "preview".
    /// Immutable for the life of the deployment (a superseded production build
    /// keeps target=production even after a newer one is promoted). Empty string
    /// means "derive from `production`" (back-compat for old in-memory values).
    pub target: String,
}

/// Admin API: request to create a deployment. For the mock backend the gateway
/// reads files directly from `root` (same host); a real deploy would upload a
/// tarball / build artifact instead.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DeployRequest {
    pub root: String,
    pub manifest: Manifest,
    #[serde(default)]
    pub creator: Option<String>,
    #[serde(default)]
    pub git: Option<GitSource>,
    #[serde(default)]
    pub production: bool,
}

/// Admin API: deploy directly from a git repository URL.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct GitDeployRequest {
    pub repo_url: String,
    #[serde(default)]
    pub branch: Option<String>,
    #[serde(default)]
    pub project: Option<String>,
    #[serde(default)]
    pub creator: Option<String>,
    #[serde(default = "default_prod")]
    pub production: bool,
    /// Explicit deploy target: "production" | "preview". When None (the default),
    /// the target is CLASSIFIED from the branch — a push to the project's
    /// production branch is production, every other branch / PR is a preview
    /// (Vercel's model). Webhooks set this to "preview" for PR events; the import
    /// + redeploy flows leave it None so the branch decides.
    #[serde(default)]
    pub target: Option<String>,
    /// Whether to reuse the existing dependency build cache. Defaults to true.
    /// A redeploy can set this false ("Use existing Build Cache" unchecked) to
    /// force a clean install — when a package-lock.json is present that means
    /// `npm ci` instead of `npm install`, and the cached node_modules is skipped.
    #[serde(default = "default_prod")]
    pub use_cache: bool,
    /// Subdirectory within the repo to build (for monorepo templates, e.g.
    /// `examples/nextjs`). Empty/None = repo root.
    #[serde(default)]
    pub root_dir: Option<String>,
    /// Environment variables to set on the project at creation, injected into
    /// BOTH the build (install/build commands) and the runtime (functions /
    /// containers). Set from the "New Project" screen.
    #[serde(default)]
    pub env: Option<std::collections::BTreeMap<String, String>>,
}
fn default_prod() -> bool {
    true
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DeploymentInfo {
    pub id: DeploymentId,
    pub project: String,
    pub functions: Vec<String>,
    pub created_at_ms: u64,
    /// Convenience: the project (production-domain) Host alias `<project>.localhost`.
    pub alias: String,
    /// Immutable per-commit Host alias `<project>-<shortsha>.localhost` (Vercel's
    /// commit URL). Empty when the deployment has no git commit. Always resolves
    /// to THIS exact deployment.
    #[serde(default)]
    pub commit_alias: String,
    /// Per-branch Host alias `<project>-git-<branch>.localhost` (Vercel's branch
    /// URL) — resolves to the latest deployment on that branch. Empty without git.
    #[serde(default)]
    pub branch_alias: String,
    /// Immutable per-deployment Host alias `<id>.localhost`, always this deployment.
    #[serde(default)]
    pub id_alias: String,
    /// Build environment: "production" | "preview" — IMMUTABLE (unlike
    /// `production`, which is the live "is currently promoted" flag).
    #[serde(default)]
    pub target: String,
    #[serde(default = "default_ready")]
    pub state: DeployState,
    #[serde(default)]
    pub creator: String,
    #[serde(default)]
    pub git: Option<GitSource>,
    #[serde(default)]
    pub production: bool,
    /// Type label for the UI: "static" | "function" | "fullstack".
    #[serde(default)]
    pub kind: String,
    /// Framework features mapped onto this deployment (redirects, middleware…).
    #[serde(default)]
    pub features: DeploymentFeatures,
}
fn default_ready() -> DeployState {
    DeployState::Ready
}

/// Summary of framework build features the platform mapped onto a deployment —
/// surfaced in the dashboard (service graph, overview).
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct DeploymentFeatures {
    pub redirects: usize,
    pub rewrites: usize,
    pub middleware: bool,
    pub edge_functions: usize,
    pub serverless_functions: usize,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn longest_prefix_wins() {
        let m = Manifest {
            project: "p".into(),
            static_dir: Some("public".into()),
            functions: vec![],
            routes: vec![
                Route { pattern: "/".into(), target: RouteTarget::Static },
                Route { pattern: "/api".into(), target: RouteTarget::Function("api".into()) },
                Route { pattern: "/api/admin".into(), target: RouteTarget::Function("admin".into()) },
            ],
            ..Default::default()
        };
        assert_eq!(m.resolve("/index.html"), RouteTarget::Static);
        assert_eq!(m.resolve("/api/users"), RouteTarget::Function("api".into()));
        assert_eq!(m.resolve("/api/admin/x"), RouteTarget::Function("admin".into()));
        assert!(!path_matches("/api", "/apixyz"));
    }
}

#[cfg(test)]
mod routing_tests {
    use super::*;

    #[test]
    fn deploy_state_defaults_to_ready() {
        assert_eq!(DeployState::default(), DeployState::Ready);
    }

    #[test]
    fn manifest_resolve_longest_prefix_wins() {
        let m = Manifest {
            routes: vec![
                Route { pattern: "/".into(), target: RouteTarget::Static },
                Route { pattern: "/api".into(), target: RouteTarget::Function("api".into()) },
            ],
            ..Default::default()
        };
        assert_eq!(m.resolve("/api/users"), RouteTarget::Function("api".into()));
        assert_eq!(m.resolve("/index.html"), RouteTarget::Static);
    }

    #[test]
    fn manifest_redirect_and_rewrite() {
        let m = Manifest {
            redirects: vec![Redirect { source: "/old".into(), destination: "/new".into(), status: 308 }],
            rewrites: vec![Rewrite { source: "/proxy".into(), destination: "/internal".into() }],
            ..Default::default()
        };
        assert_eq!(m.redirect_for("/old"), Some(("/new".to_string(), 308)));
        assert_eq!(m.redirect_for("/nope"), None);
        assert_eq!(m.rewrite_path("/proxy"), "/internal");
        assert_eq!(m.rewrite_path("/untouched"), "/untouched");
    }

    #[test]
    fn deploy_record_state_defaults_when_absent() {
        // Snapshots written before `state` existed deserialize to Ready.
        let json = r#"{"id":"d1","project":"p","root":"/tmp","manifest":{"project":"p"},"created_at_ms":0,"creator":"you","git":null,"production":true}"#;
        let rec: DeployRecord = serde_json::from_str(json).expect("deserializes without state");
        assert_eq!(rec.state, DeployState::Ready);
    }
}
