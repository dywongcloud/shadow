//! `fluid-gateway` — the public router.
//!
//! This is the Vercel "Functions router" analogue. For each incoming request it:
//! 1. selects the target deployment (by `Host` subdomain, else the default),
//! 2. resolves the path to a route (static asset vs function),
//! 3. serves the file, or leases a Fluid instance and proxies the request to it.
//!
//! Each instance is reached over a single **multiplexed tunnel**
//! ([`fluid_tunnel::TunnelClient`]): one persistent connection carries many
//! concurrent requests (stream-id framing) plus in-band metrics and nack. The
//! gateway keeps one tunnel per instance and reuses it for every request.

use axum::{
    body::{Body, Bytes},
    extract::{Request, State},
    http::{header, HeaderMap, HeaderName, HeaderValue, Method, StatusCode},
    response::{IntoResponse, Response},
    routing::{get, post},
    Json, Router,
};
use fluid_compute::{func_key, Fluid, FunctionStats};
use fluid_core::{Deployment, DeploymentId, DeploymentInfo, DeployRequest, Manifest, RouteTarget};
use fluid_tunnel::TunnelClient;
use hive_backend::connect_endpoint;
use hive_core::{now_ms, CellId};
use parking_lot::Mutex;
use serde::Serialize;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tracing::warn;

struct GwState {
    deployments: HashMap<DeploymentId, Deployment>,
    /// project name -> current deployment id.
    aliases: HashMap<String, DeploymentId>,
    default: Option<DeploymentId>,
}

pub struct Gateway {
    fluid: Arc<Fluid>,
    /// Image/rootfs used for function cells (matters for the firecracker backend).
    image: String,
    state: Mutex<GwState>,
    /// One multiplexed tunnel per instance (cell), reused for all its requests.
    /// Async mutex so creation is serialized per gateway (no duplicate/orphan
    /// tunnels race) — held only briefly across the connect.
    tunnels: tokio::sync::Mutex<HashMap<CellId, Arc<TunnelClient>>>,
    tunnels_opened: AtomicU64,
    tunnels_reused: AtomicU64,
}

impl Gateway {
    pub fn new(fluid: Arc<Fluid>, image: String) -> Arc<Gateway> {
        Arc::new(Gateway {
            fluid,
            image,
            state: Mutex::new(GwState {
                deployments: HashMap::new(),
                aliases: HashMap::new(),
                default: None,
            }),
            tunnels: tokio::sync::Mutex::new(HashMap::new()),
            tunnels_opened: AtomicU64::new(0),
            tunnels_reused: AtomicU64::new(0),
        })
    }

    /// Get the live tunnel for an instance, opening one if needed. Creation is
    /// serialized under the async lock so concurrent first-requests to the same
    /// instance share ONE tunnel (no orphan connections).
    async fn tunnel_for(
        &self,
        cell: &CellId,
        ep: &hive_backend::CellEndpoint,
    ) -> anyhow::Result<(Arc<TunnelClient>, bool)> {
        let mut map = self.tunnels.lock().await;
        if let Some(c) = map.get(cell) {
            if !c.is_closed() {
                self.tunnels_reused.fetch_add(1, Ordering::Relaxed);
                return Ok((c.clone(), true));
            }
        }
        let stream = connect_endpoint(ep).await?;
        let client = Arc::new(TunnelClient::new(stream));
        map.insert(cell.clone(), client.clone());
        self.tunnels_opened.fetch_add(1, Ordering::Relaxed);
        Ok((client, false))
    }

    async fn drop_tunnel(&self, cell: &CellId) {
        self.tunnels.lock().await.remove(cell);
    }

    /// Register a deployment: wire its functions into the Fluid pool and make it
    /// routable. Becomes the default (most-recent) deployment.
    pub fn deploy(&self, root: String, manifest: Manifest) -> DeploymentInfo {
        self.deploy_full(root, manifest, "you".into(), None, true, fluid_core::DeployState::Ready, String::new())
    }

    /// Name of the active isolation backend ("mock" | "firecracker").
    pub fn backend_name(&self) -> &'static str {
        self.fluid.backend_name()
    }

    /// Pack a built deployment's output so the serving cells can reach it (only
    /// meaningful for an isolated backend; a no-op for the same-host mock).
    pub async fn deliver_build(&self, image: &str, build_dir: &std::path::Path) -> anyhow::Result<()> {
        self.fluid.deliver_build(image, build_dir).await
    }

    /// Full deploy with creator + git provenance + production flag + owning tenant.
    /// `tenant` (empty = "personal") tags the deployment and every function pool /
    /// cell it spawns, so compute is partitioned and quota'd per team.
    #[allow(clippy::too_many_arguments)]
    pub fn deploy_full(
        &self,
        root: String,
        manifest: Manifest,
        creator: String,
        git: Option<fluid_core::GitSource>,
        production: bool,
        state: fluid_core::DeployState,
        tenant: String,
    ) -> DeploymentInfo {
        // Normalize the owner once at the boundary so the stored record, the
        // function pools, and every cell agree on the tenant (empty => "personal").
        let tenant = if tenant.trim().is_empty() { "personal".to_string() } else { tenant };
        let id = DeploymentId::new();
        let workdir_root = root.clone();
        let cell_image = manifest.image.clone().unwrap_or_else(|| self.image.clone());
        for f in &manifest.functions {
            let key = func_key(id.as_str(), &f.name);
            self.fluid
                .register(key, f.clone(), cell_image.clone(), workdir_root.clone(), tenant.clone());
        }
        let dep = Deployment {
            id: id.clone(),
            project: manifest.project.clone(),
            root: PathBuf::from(root),
            manifest: manifest.clone(),
            created_at_ms: now_ms(),
            state,
            creator,
            git,
            production,
            // The build target is immutable; `production` (promoted) may later flip.
            target: if production { "production".into() } else { "preview".into() },
            tenant,
        };
        let info = view_of(&dep);
        let project = dep.project.clone();
        let mut st = self.state.lock();
        // Does this project already have a (different) production deployment? If
        // not, this deploy claims the bare production domain even when it isn't
        // itself a production deploy — so the very first deploy and the "Building…"
        // placeholder are reachable at <project>.<host> right away.
        let has_production = st
            .deployments
            .values()
            .any(|d| d.project == project && d.production && d.id != id);
        // Invariant: at most ONE production deployment per project. Promoting this
        // one to production demotes any prior production deployment of the same
        // project, so the production alias can't later resolve to a stale deployment
        // after a restart (which would serve the OLD build).
        if production {
            for d in st.deployments.values_mut() {
                if d.project == project {
                    d.production = false;
                }
            }
        }
        st.deployments.insert(id.clone(), dep);
        // Vercel's 3 URL types: the immutable per-deployment + commit URLs and the
        // mutable branch URL (latest on that branch).
        insert_deploy_aliases(&mut st, &id);
        // Production domain (<project>) + default fallback move only on a production
        // deploy — a preview deploy of an existing project must NOT hijack prod.
        // Exception: the project's first-ever deploy claims it so the URL resolves.
        if production || !has_production {
            st.aliases.insert(project, id.clone());
            st.default = Some(id.clone());
        }
        info
    }

    /// Resolve which project serves a given request host (the same way the
    /// public router selects), so events can be attributed to a project.
    pub fn project_for_host(&self, host: &str) -> Option<String> {
        self.select(Some(host)).map(|d| d.project)
    }

    /// The full deployment a request `host` resolves to (same alias resolution the
    /// public router uses). Exposes `target`/`production` so the preview gate can
    /// decide protection by the deployment's ACTUAL environment — not by guessing
    /// from the subdomain (which wrongly flags a production deployment's commit/id
    /// URLs as previews).
    pub fn deployment_for_host(&self, host: &str) -> Option<DeploymentInfo> {
        self.select(Some(host)).map(|d| view_of(&d))
    }

    /// Attach a custom domain to a project (its first label aliases to the
    /// project's current deployment). Returns true if the project exists.
    pub fn add_alias(&self, domain: &str, project: &str) -> bool {
        let label = domain.split('.').next().unwrap_or(domain).to_string();
        let mut st = self.state.lock();
        let target = st.aliases.get(project).cloned();
        if let Some(id) = target {
            st.aliases.insert(label, id);
            true
        } else {
            false
        }
    }

    /// Promote an existing deployment to be its project's production (rollback /
    /// instant promote). Re-points the project alias + default to it.
    pub fn promote(&self, id: &str) -> Option<DeploymentInfo> {
        let did = DeploymentId::from(id.to_string());
        let mut st = self.state.lock();
        let project = st.deployments.get(&did)?.project.clone();
        // Flip production flags within the project.
        for d in st.deployments.values_mut() {
            if d.project == project {
                d.production = d.id == did;
            }
        }
        st.aliases.insert(project, did.clone());
        st.default = Some(did.clone());
        st.deployments.get(&did).map(view_of)
    }

    /// Keep-warm reconciliation: only the PRODUCTION deployment of each project
    /// keeps its configured `min_instances` warm; every superseded (non-production)
    /// deployment is drained to zero. Without this, each redeploy left an old
    /// deployment pinning an idle warm instance (N warm microVMs per project).
    /// Idempotent — safe to call on a timer and after deploy/promote.
    pub fn reconcile_keepwarm(&self) {
        let st = self.state.lock();
        for d in st.deployments.values() {
            for f in &d.manifest.functions {
                let key = func_key(d.id.as_str(), &f.name);
                let n = if d.production { f.min_instances } else { 0 };
                self.fluid.set_min_instances(&key, n);
            }
        }
    }

    /// Delete a single deployment: unregister its functions and drop it. Returns
    /// the project it belonged to (so callers can persist / re-point).
    pub async fn remove(&self, id: &str) -> Option<String> {
        let did = DeploymentId::from(id.to_string());
        let (project, keys) = {
            let st = self.state.lock();
            let dep = st.deployments.get(&did)?;
            let keys: Vec<String> = dep
                .manifest
                .functions
                .iter()
                .map(|f| func_key(did.as_str(), &f.name))
                .collect();
            (dep.project.clone(), keys)
        };
        for k in keys {
            self.fluid.unregister(&k).await;
        }
        let mut st = self.state.lock();
        st.deployments.remove(&did);
        // Drop any aliases that pointed at this deployment.
        st.aliases.retain(|_, v| *v != did);
        if st.default.as_ref() == Some(&did) {
            st.default = st
                .deployments
                .values()
                .max_by_key(|d| d.created_at_ms)
                .map(|d| d.id.clone());
        }
        // Re-point the project alias to its newest remaining deployment.
        if let Some(newest) = st
            .deployments
            .values()
            .filter(|d| d.project == project)
            .max_by_key(|d| d.created_at_ms)
            .map(|d| d.id.clone())
        {
            st.aliases.insert(project.clone(), newest);
        }
        Some(project)
    }

    /// Delete every deployment for a project. Returns the removed deployment ids.
    pub async fn remove_project(&self, project: &str) -> Vec<String> {
        let ids: Vec<String> = {
            let st = self.state.lock();
            st.deployments
                .values()
                .filter(|d| d.project == project)
                .map(|d| d.id.to_string())
                .collect()
        };
        for id in &ids {
            self.remove(id).await;
        }
        ids
    }

    /// The git source of a project's newest deployment (for "redeploy").
    pub fn git_for_project(&self, project: &str) -> Option<fluid_core::GitSource> {
        let st = self.state.lock();
        st.deployments
            .values()
            .filter(|d| d.project == project)
            .max_by_key(|d| d.created_at_ms)
            .and_then(|d| d.git.clone())
    }

    pub fn list(&self) -> Vec<DeploymentInfo> {
        let st = self.state.lock();
        let mut out: Vec<DeploymentInfo> = st.deployments.values().map(view_of).collect();
        out.sort_by_key(|d| std::cmp::Reverse(d.created_at_ms));
        out
    }

    /// Serializable snapshot of all deployments (for persistence).
    pub fn deployment_records(&self) -> Vec<fluid_core::DeployRecord> {
        let st = self.state.lock();
        st.deployments
            .values()
            .map(|d| fluid_core::DeployRecord {
                id: d.id.to_string(),
                project: d.project.clone(),
                root: d.root.to_string_lossy().into_owned(),
                manifest: d.manifest.clone(),
                created_at_ms: d.created_at_ms,
                creator: d.creator.clone(),
                git: d.git.clone(),
                production: d.production,
                target: d.target.clone(),
                state: d.state,
                tenant: d.tenant.clone(),
            })
            .collect()
    }

    /// Restore a deployment from a persisted record (preserves its id), and
    /// re-register its functions with the Fluid pool. Used on boot.
    pub fn restore(&self, rec: fluid_core::DeployRecord) {
        let id = DeploymentId::from(rec.id.clone());
        let cell_image = rec.manifest.image.clone().unwrap_or_else(|| self.image.clone());
        for f in &rec.manifest.functions {
            let key = func_key(id.as_str(), &f.name);
            self.fluid.register(key, f.clone(), cell_image.clone(), rec.root.clone(), rec.tenant.clone());
        }
        let dep = Deployment {
            id: id.clone(),
            project: rec.project.clone(),
            root: PathBuf::from(&rec.root),
            manifest: rec.manifest,
            created_at_ms: rec.created_at_ms,
            state: rec.state,
            creator: rec.creator,
            git: rec.git,
            production: rec.production,
            // Old snapshots have no target — derive it from the production flag.
            target: if rec.target.is_empty() {
                if rec.production { "production".into() } else { "preview".into() }
            } else {
                rec.target
            },
            tenant: rec.tenant,
        };
        let project = dep.project.clone();
        let mut st = self.state.lock();
        st.deployments.insert(id.clone(), dep);
        // The project (production) alias must resolve to the project's CURRENT
        // deployment, not whichever record happens to restore last. Prefer the
        // production deployment, and among equals the newest — so a stale prior
        // deployment (e.g. a superseded build) never wins the alias after a reboot.
        set_alias_if_newer(&mut st, &project, &id);
        // The per-deployment preview URL + commit/branch URLs (branch tracks the
        // newest deployment on that branch — set_alias_if_newer handles ordering).
        insert_deploy_aliases(&mut st, &id);
        st.default.get_or_insert(id);
    }

    /// Pick the deployment for a request: `<project>.<host>` subdomain, else the
    /// most recent deployment.
    fn select(&self, host: Option<&str>) -> Option<Deployment> {
        let st = self.state.lock();
        if let Some(h) = host {
            let h = h.split(':').next().unwrap_or(h); // strip port
            let sub = h.split('.').next().unwrap_or(h);
            if let Some(id) = st.aliases.get(sub) {
                return st.deployments.get(id).cloned();
            }
        }
        st.default.as_ref().and_then(|id| st.deployments.get(id).cloned())
    }

    /// The deployment id a request `host` resolves to (its subdomain alias), if
    /// any. Exposes the same alias resolution `select` uses — handy for debugging
    /// and for asserting which deployment a project host points at.
    pub fn host_deployment_id(&self, host: &str) -> Option<String> {
        let h = host.split(':').next().unwrap_or(host);
        let sub = h.split('.').next().unwrap_or(h);
        self.state.lock().aliases.get(sub).map(|id| id.as_str().to_string())
    }

    /// Does THIS node actually have a deployment aliased for `host`'s subdomain?
    /// Exact alias match (no default fallback) — used by mesh routing to decide
    /// whether to serve locally or proxy to the peer that really hosts it.
    pub fn serves_host(&self, host: &str) -> bool {
        let h = host.split(':').next().unwrap_or(host);
        let sub = h.split('.').next().unwrap_or(h);
        self.state.lock().aliases.contains_key(sub)
    }

    /// All host subdomains this node serves (project aliases + deployment ids),
    /// published to peers so the mesh knows where each deployment lives.
    pub fn served_hosts(&self) -> Vec<String> {
        self.state.lock().aliases.keys().cloned().collect()
    }

    /// Projects this node hosts that are **container** deployments (a function with
    /// the `container` runtime) — these are the stateful workloads coordinated by a
    /// single-owner lease. Functions/static sites are excluded (stateless).
    pub fn container_projects(&self) -> Vec<String> {
        let st = self.state.lock();
        let mut out: Vec<String> = st
            .deployments
            .values()
            .filter(|d| d.manifest.functions.iter().any(|f| f.runtime == "container"))
            .map(|d| d.project.clone())
            .collect();
        out.sort();
        out.dedup();
        out
    }

    /// Is the deployment behind `host` a container deployment?
    pub fn is_container_host(&self, host: &str) -> bool {
        let h = host.split(':').next().unwrap_or(host);
        let sub = h.split('.').next().unwrap_or(h);
        let st = self.state.lock();
        st.aliases
            .get(sub)
            .and_then(|id| st.deployments.get(id))
            .map(|d| d.manifest.functions.iter().any(|f| f.runtime == "container"))
            .unwrap_or(false)
    }
}

// ---- routers ---------------------------------------------------------------

pub fn public_router(gw: Arc<Gateway>) -> Router {
    Router::new().fallback(handle_public).with_state(gw)
}

pub fn admin_router(gw: Arc<Gateway>) -> Router {
    Router::new()
        .route("/healthz", get(|| async { "ok" }))
        .route("/deployments", post(admin_deploy).get(admin_list))
        .route("/stats", get(admin_stats))
        .route("/tunnels", get(admin_tunnels))
        .with_state(gw)
}

#[derive(Serialize, Clone, Default)]
pub struct TunnelStats {
    pub tunnels_opened: u64,
    pub tunnels_reused: u64,
    pub reuse_pct: f64,
    pub live_tunnels: usize,
    /// Aggregate tunnel byte/backpressure metering across live tunnels (#14).
    pub bytes_in: u64,
    pub bytes_out: u64,
    /// Sum of current write-queue depth across live tunnels (downstream backpressure).
    pub queue_depth: u32,
    /// Cumulative backpressure high-water trips across live tunnels.
    pub backpressure_events: u64,
    /// Live tunnels currently showing a non-empty write queue (under backpressure).
    pub tunnels_backpressured: usize,
}

impl Gateway {
    /// Tunnel reuse + #14 byte/backpressure metering, aggregated across live
    /// tunnels. Exposed so the node admin API can surface it.
    pub async fn tunnel_stats(&self) -> TunnelStats {
        let opened = self.tunnels_opened.load(Ordering::Relaxed);
        let reused = self.tunnels_reused.load(Ordering::Relaxed);
        let total = opened + reused;
        let reuse_pct = if total > 0 { reused as f64 / total as f64 } else { 0.0 };
        let (mut bytes_in, mut bytes_out, mut queue_depth, mut bp, mut backpressured) =
            (0u64, 0u64, 0u32, 0u64, 0usize);
        let live = self.tunnels.lock().await;
        for client in live.values() {
            let h = client.health();
            bytes_in += h.bytes_in;
            bytes_out += h.bytes_out;
            queue_depth += h.queue_depth;
            bp += h.backpressure_events;
            if h.queue_depth > 0 {
                backpressured += 1;
            }
        }
        let live_tunnels = live.len();
        drop(live);
        TunnelStats {
            tunnels_opened: opened,
            tunnels_reused: reused,
            reuse_pct,
            live_tunnels,
            bytes_in,
            bytes_out,
            queue_depth,
            backpressure_events: bp,
            tunnels_backpressured: backpressured,
        }
    }
}

async fn admin_tunnels(State(gw): State<Arc<Gateway>>) -> Json<TunnelStats> {
    Json(gw.tunnel_stats().await)
}

pub async fn serve_public(gw: Arc<Gateway>, addr: std::net::SocketAddr) -> anyhow::Result<()> {
    let l = tokio::net::TcpListener::bind(addr).await?;
    tracing::info!(%addr, "fluid gateway (public) listening");
    axum::serve(l, public_router(gw)).await?;
    Ok(())
}

pub async fn serve_admin(gw: Arc<Gateway>, addr: std::net::SocketAddr) -> anyhow::Result<()> {
    let l = tokio::net::TcpListener::bind(addr).await?;
    tracing::info!(%addr, "fluid gateway (admin) listening");
    axum::serve(l, admin_router(gw)).await?;
    Ok(())
}

async fn admin_deploy(
    State(gw): State<Arc<Gateway>>,
    Json(req): Json<DeployRequest>,
) -> Json<DeploymentInfo> {
    Json(gw.deploy(req.root, req.manifest))
}

async fn admin_list(State(gw): State<Arc<Gateway>>) -> Json<Vec<DeploymentInfo>> {
    Json(gw.list())
}

async fn admin_stats(State(gw): State<Arc<Gateway>>) -> Json<Vec<FunctionStats>> {
    Json(gw.fluid.stats())
}

// ---- public request handling ----------------------------------------------

async fn handle_public(State(gw): State<Arc<Gateway>>, req: Request) -> Response {
    let (parts, body) = req.into_parts();
    let host = parts
        .headers
        .get(header::HOST)
        .and_then(|v| v.to_str().ok())
        .map(|s| s.to_string());
    let path = parts.uri.path().to_string();
    let path_q = parts
        .uri
        .path_and_query()
        .map(|pq| pq.as_str().to_string())
        .unwrap_or_else(|| "/".to_string());

    // Vercel analytics / speed-insights compatibility: the `@vercel/analytics`
    // and `@vercel/speed-insights` packages load a same-origin script and beacon
    // their data here. Handle these before deployment routing so any deployed app
    // using the official packages works unchanged.
    if path.starts_with("/_vercel/") {
        if let Some(resp) = vercel_insights(&parts.method, &path) {
            return resp;
        }
    }

    let dep = match gw.select(host.as_deref()) {
        Some(d) => d,
        None => return (StatusCode::NOT_FOUND, "no deployment").into_response(),
    };

    // Image Optimization API (`vercel.json` `images`). Next.js' `<Image>` loader
    // hits `/_next/image`; the Vercel runtime endpoint is `/_vercel/image`.
    if path == "/_vercel/image" || path == "/_next/image" {
        return serve_optimized_image(&dep, parts.uri.query().unwrap_or(""), &parts.headers).await;
    }

    // Request context for `has`/`missing` conditions + host-scoped matching.
    let query = parts.uri.query().unwrap_or("").to_string();
    let with_query = |loc: String| -> String {
        if query.is_empty() { loc } else { format!("{loc}?{query}") }
    };
    let ctx = fluid_core::ReqCtx {
        host: host.clone().unwrap_or_default(),
        headers: parts
            .headers
            .iter()
            .filter_map(|(k, v)| v.to_str().ok().map(|vs| (k.as_str().to_ascii_lowercase(), vs.to_string())))
            .collect(),
        query: query.clone(),
    };
    // The original path drives `headers` matching (Vercel matches the incoming
    // path, before any rewrite).
    let orig_path = path.clone();
    let redirect = |status: u16, location: String| -> Response {
        let code = StatusCode::from_u16(status).unwrap_or(StatusCode::TEMPORARY_REDIRECT);
        Response::builder()
            .status(code)
            .header(header::LOCATION, location)
            .body(Body::empty())
            .unwrap()
            .into_response()
    };

    // 1) trailingSlash normalization (308 add/remove the trailing slash).
    if let Some(newp) = dep.manifest.trailing_slash_redirect(&path) {
        return redirect(308, with_query(newp));
    }
    // 2) cleanUrls: a request for `/about.html` 308-redirects to `/about`
    //    (the extensionless form is served directly — see serve_static).
    if dep.manifest.clean_urls && path.ends_with(".html") {
        let mut clean = path.trim_end_matches(".html").to_string();
        if clean.ends_with("/index") {
            clean.truncate(clean.len() - "index".len()); // ".../index" -> ".../"
        }
        if clean.is_empty() {
            clean = "/".into();
        }
        if clean != path {
            return redirect(308, with_query(clean));
        }
    }
    // 3) Redirects (vercel.json + framework), honoring has/missing + :param.
    if let Some((location, status)) = dep.manifest.redirect_for_ctx(&path, &ctx) {
        return redirect(status, location);
    }
    // 4) Rewrites map the public path to an internal one (client URL unchanged).
    let path = dep.manifest.rewrite_path_ctx(&path, &ctx);

    // 5) Response headers from `vercel.json` `headers` (matched on the incoming
    //    path) are injected onto whatever the route produces.
    let extra_headers = dep.manifest.headers_for(&orig_path, &ctx);

    let resp = match dep.manifest.resolve(&path) {
        RouteTarget::Static => serve_static(&dep, &path).await,
        RouteTarget::Function(name) => {
            let body_bytes = match axum::body::to_bytes(body, 16 * 1024 * 1024).await {
                Ok(b) => b,
                Err(_) => return (StatusCode::BAD_REQUEST, "body too large").into_response(),
            };
            proxy_function(&gw, &dep, &name, &parts.method, &path_q, &parts.headers, body_bytes)
                .await
        }
    };
    // Per-route policy (#16): when this deployment carries Next.js per-route
    // classification, apply route-type-aware caching to the response. Matched on
    // the ORIGINAL request path (route patterns are user-facing, pre-rewrite).
    // No-op when `route_policies` is empty (the common case) -> byte-identical.
    let resp = apply_route_policy(resp, &dep, &orig_path);
    inject_headers(resp, &extra_headers)
}

/// Apply a deployment's per-route policy (#16) to a response: tag it with the
/// matched route class for observability, and — for Static/ISR routes whose
/// origin didn't set its own `Cache-Control` — synthesize the route-type cache
/// header (Static => immutable, ISR => `s-maxage=revalidate, SWR`). Purely
/// additive: returns the response untouched when no policy matches, when the
/// origin already set caching, or for non-success statuses.
fn apply_route_policy(mut resp: Response, dep: &Deployment, path: &str) -> Response {
    let Some(policy) = dep.manifest.route_policy(path) else {
        return resp;
    };
    // Observability: surfaces which class served the request (enables live verify).
    resp.headers_mut().insert("x-hive-route-class", HeaderValue::from_static(policy.class.name()));
    // Only synthesize caching for cacheable (2xx) responses that don't already
    // carry a Cache-Control from the origin (don't override the app's intent).
    if !resp.status().is_success() || resp.headers().contains_key(header::CACHE_CONTROL) {
        return resp;
    }
    if let Some(cc) = policy.class.cache_policy(policy.revalidate).cache_control() {
        if let Ok(v) = HeaderValue::from_str(&cc) {
            resp.headers_mut().insert(header::CACHE_CONTROL, v);
        }
    }
    resp
}

/// Apply configured response headers (`vercel.json` `headers`) onto a response.
fn inject_headers(mut resp: Response, extra: &[(String, String)]) -> Response {
    if extra.is_empty() {
        return resp;
    }
    let h = resp.headers_mut();
    for (k, v) in extra {
        if let (Ok(name), Ok(val)) = (HeaderName::from_bytes(k.as_bytes()), HeaderValue::from_str(v)) {
            h.insert(name, val);
        }
    }
    resp
}

/// Vercel Web Analytics + Speed Insights endpoints.
///
/// * `GET  /_vercel/insights/script.js`        — analytics loader (sends pageviews/events)
/// * `POST /_vercel/insights/view|event`       — beacon sink (202)
/// * `GET  /_vercel/speed-insights/script.js`  — web-vitals collector
/// * `POST /_vercel/speed-insights/vitals`     — beacon sink (202)
fn vercel_insights(method: &Method, path: &str) -> Option<Response> {
    const ANALYTICS_JS: &str = r#"(function(){function send(t,d){try{navigator.sendBeacon('/_vercel/insights/'+t,JSON.stringify(d||{}))}catch(e){}}
function va(){var a=[].slice.call(arguments),k=a[0];if(k==='event')send('event',a[1]||{});else send('view',a[1]||{})}
var q=window.vaq||[];window.va=va;window.vaq={push:function(args){va.apply(null,args)}};
q.forEach(function(args){va.apply(null,args)});send('view',{u:location.pathname});})();"#;

    const SPEED_JS: &str = r#"(function(){var v={};function send(){try{navigator.sendBeacon('/_vercel/speed-insights/vitals',JSON.stringify({href:location.href,vitals:v}))}catch(e){}}
try{new PerformanceObserver(function(l){l.getEntries().forEach(function(e){if(e.name==='first-contentful-paint')v.FCP=e.startTime})}).observe({type:'paint',buffered:true});
new PerformanceObserver(function(l){var es=l.getEntries();v.LCP=es[es.length-1].startTime}).observe({type:'largest-contentful-paint',buffered:true});
var cls=0;new PerformanceObserver(function(l){l.getEntries().forEach(function(e){if(!e.hadRecentInput)cls+=e.value});v.CLS=cls}).observe({type:'layout-shift',buffered:true});
new PerformanceObserver(function(l){l.getEntries().forEach(function(e){v.INP=Math.max(v.INP||0,e.duration)})}).observe({type:'event',buffered:true,durationThreshold:40})}catch(e){}
try{var n=performance.getEntriesByType('navigation')[0];if(n)v.TTFB=n.responseStart}catch(e){}
addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')send()});addEventListener('pagehide',send);})();"#;

    let js = |body: &'static str| -> Response {
        Response::builder()
            .status(StatusCode::OK)
            .header(header::CONTENT_TYPE, "application/javascript; charset=utf-8")
            .header(header::CACHE_CONTROL, "public, max-age=3600")
            .body(Body::from(body))
            .unwrap()
            .into_response()
    };
    let accepted = || (StatusCode::ACCEPTED, [(header::CONTENT_TYPE, "text/plain")], "ok").into_response();

    match (method, path) {
        (&Method::GET, "/_vercel/insights/script.js") => Some(js(ANALYTICS_JS)),
        (&Method::GET, "/_vercel/speed-insights/script.js") => Some(js(SPEED_JS)),
        (&Method::POST, "/_vercel/insights/view")
        | (&Method::POST, "/_vercel/insights/event")
        | (&Method::POST, "/_vercel/speed-insights/vitals") => Some(accepted()),
        // Image Optimization is handled per-deployment after selection.
        (_, "/_vercel/image") => None,
        // Unknown _vercel path: 204 so the client never sees a hard 404.
        _ => Some((StatusCode::NO_CONTENT, "").into_response()),
    }
}

/// Vercel-standard `Cache-Control` for a served static asset. Content-hashed
/// build assets (Next.js `/_next/static/**`, or Vite/webpack `name.<hex>.ext`)
/// are immutable and cached for a year; everything else uses Vercel's default
/// (`public, max-age=0, must-revalidate`) — which our CDN treats as
/// non-storable, so a redeploy never serves stale non-hashed content.
fn static_cache_control(path: &str) -> &'static str {
    let file = path.rsplit('/').next().unwrap_or("");
    if path.contains("/_next/static/") || is_hashed_asset(file) {
        "public, max-age=31536000, immutable"
    } else {
        "public, max-age=0, must-revalidate"
    }
}

/// True if a filename carries a content hash (a `.`/`-`-delimited hex token of
/// 8+ chars containing a digit), e.g. `index-4f3a9c2b.js`, `main.1a2b3c4d.css`.
fn is_hashed_asset(file: &str) -> bool {
    file.split(['.', '-']).any(|seg| {
        seg.len() >= 8 && seg.bytes().all(|b| b.is_ascii_hexdigit()) && seg.bytes().any(|b| b.is_ascii_digit())
    })
}

async fn serve_static(dep: &Deployment, path: &str) -> Response {
    let static_dir = dep.manifest.static_dir.clone().unwrap_or_else(|| ".".into());
    let base = dep.root.join(static_dir);
    let rel = path.trim_start_matches('/');
    let mut file = base.join(rel);
    // Directory or root -> index.html.
    if path.ends_with('/') || rel.is_empty() {
        file = file.join("index.html");
    }
    // Path-traversal guard: resolved file must stay under base.
    if !is_within(&base, &file) {
        return (StatusCode::FORBIDDEN, "forbidden").into_response();
    }
    match tokio::fs::read(&file).await {
        Ok(bytes) => {
            let ctype = content_type(&file);
            (
                [(header::CONTENT_TYPE, ctype), (header::CACHE_CONTROL, static_cache_control(path))],
                bytes,
            )
                .into_response()
        }
        Err(_) => {
            // cleanUrls: serve `about.html` for a request to `/about`.
            if dep.manifest.clean_urls && !rel.is_empty() && !path.ends_with('/') {
                let html = base.join(format!("{rel}.html"));
                if is_within(&base, &html) {
                    if let Ok(bytes) = tokio::fs::read(&html).await {
                        return (
                            [
                                (header::CONTENT_TYPE, "text/html; charset=utf-8"),
                                (header::CACHE_CONTROL, "public, max-age=0, must-revalidate"),
                            ],
                            bytes,
                        )
                            .into_response();
                    }
                }
            }
            // SPA-ish fallback: try index.html at the static root.
            let idx = base.join("index.html");
            if let Ok(bytes) = tokio::fs::read(&idx).await {
                (
                    [
                        (header::CONTENT_TYPE, "text/html"),
                        (header::CACHE_CONTROL, "public, max-age=0, must-revalidate"),
                    ],
                    bytes,
                )
                    .into_response()
            } else {
                (StatusCode::NOT_FOUND, "not found").into_response()
            }
        }
    }
}

/// Vercel Image Optimization API (`/_vercel/image`, also `/_next/image`).
/// Validates the request against the deployment's `images` config, fetches the
/// source (local asset or allow-listed remote), and re-encodes it at the
/// requested width/quality. Resizing uses the pure-Rust `image` crate.
async fn serve_optimized_image(dep: &Deployment, query: &str, req_headers: &HeaderMap) -> Response {
    let bad = |m: &str| (StatusCode::BAD_REQUEST, m.to_string()).into_response();

    // ---- parse query ----
    let mut url = String::new();
    let mut w: Option<u32> = None;
    let mut q: u32 = 75;
    for (k, v) in parse_query(query) {
        match k.as_str() {
            "url" => url = v,
            "w" => w = v.parse().ok(),
            "q" => {
                if let Ok(n) = v.parse() {
                    q = n;
                }
            }
            _ => {}
        }
    }
    if url.is_empty() {
        return bad("missing `url`");
    }
    let Some(width) = w else { return bad("missing `w`") };
    if width == 0 || width > 4096 {
        return bad("invalid `w`");
    }

    let cfg = dep.manifest.images.as_ref();
    // Enforce the allow-lists when configured.
    if let Some(c) = cfg {
        if !c.sizes.is_empty() && !c.sizes.contains(&width) {
            return bad("`w` not in images.sizes");
        }
        if !c.qualities.is_empty() && !c.qualities.contains(&q) {
            return bad("`q` not in images.qualities");
        }
    }
    let q = q.clamp(1, 100) as u8;

    // ---- resolve + fetch the source ----
    let is_remote = url.starts_with("http://") || url.starts_with("https://");
    let (bytes, is_svg): (Vec<u8>, bool) = if is_remote {
        // Remote sources require an allow-list (no open proxy / SSRF).
        let allowed = cfg.map(|c| remote_allowed(c, &url)).unwrap_or(false);
        if !allowed {
            return bad("remote url not allowed by images.remotePatterns/domains");
        }
        let client = match reqwest::Client::builder().timeout(Duration::from_secs(15)).build() {
            Ok(c) => c,
            Err(_) => return (StatusCode::BAD_GATEWAY, "image fetch failed").into_response(),
        };
        match client.get(&url).send().await {
            Ok(r) if r.status().is_success() => {
                let svg = r
                    .headers()
                    .get(header::CONTENT_TYPE)
                    .and_then(|v| v.to_str().ok())
                    .map(|t| t.contains("svg"))
                    .unwrap_or(false);
                match r.bytes().await {
                    Ok(b) if b.len() <= 16 * 1024 * 1024 => (b.to_vec(), svg || url.ends_with(".svg")),
                    _ => return (StatusCode::BAD_GATEWAY, "image too large").into_response(),
                }
            }
            _ => return (StatusCode::BAD_GATEWAY, "image fetch failed").into_response(),
        }
    } else {
        // Local asset: validate localPatterns (when set), read from static dir.
        if let Some(c) = cfg {
            if !c.local_patterns.is_empty() && !local_allowed(c, &url) {
                return bad("local url not allowed by images.localPatterns");
            }
        }
        let static_dir = dep.manifest.static_dir.clone().unwrap_or_else(|| ".".into());
        let base = dep.root.join(static_dir);
        let rel = url.split('?').next().unwrap_or(&url).trim_start_matches('/');
        let file = base.join(rel);
        if !is_within(&base, &file) {
            return bad("forbidden");
        }
        match tokio::fs::read(&file).await {
            Ok(b) => (b, rel.ends_with(".svg")),
            Err(_) => return (StatusCode::NOT_FOUND, "image not found").into_response(),
        }
    };

    // ---- SVG: not rasterized; passthrough only when explicitly allowed ----
    if is_svg {
        let allow_svg = cfg.and_then(|c| c.dangerously_allow_svg).unwrap_or(false);
        if !allow_svg {
            return bad("SVG optimization disabled (set images.dangerouslyAllowSVG)");
        }
        return image_response(bytes, "image/svg+xml", cfg);
    }

    // ---- decode → resize → encode (CPU-bound: off the async runtime) ----
    let accept_webp = req_headers
        .get(header::ACCEPT)
        .and_then(|v| v.to_str().ok())
        .map(|a| a.contains("image/webp"))
        .unwrap_or(false);
    let formats = cfg.map(|c| c.formats.clone()).unwrap_or_default();
    let encoded = tokio::task::spawn_blocking(move || optimize_bytes(&bytes, width, q, accept_webp, &formats)).await;
    match encoded {
        Ok(Some((out, ctype))) => image_response(out, ctype, cfg),
        _ => (StatusCode::UNPROCESSABLE_ENTITY, "could not process image").into_response(),
    }
}

/// Build the optimized-image response with caching / disposition / CSP headers.
fn image_response(body: Vec<u8>, ctype: &str, cfg: Option<&fluid_core::ImagesConfig>) -> Response {
    let ttl = cfg.and_then(|c| c.minimum_cache_ttl).unwrap_or(60);
    let mut b = Response::builder()
        .status(StatusCode::OK)
        .header(header::CONTENT_TYPE, ctype)
        .header(header::CACHE_CONTROL, format!("public, max-age={ttl}, must-revalidate"));
    if let Some(c) = cfg {
        if let Some(disp) = &c.content_disposition_type {
            b = b.header(header::CONTENT_DISPOSITION, disp.clone());
        }
        if let Some(csp) = &c.content_security_policy {
            b = b.header("content-security-policy", csp.clone());
        }
    }
    b.body(Body::from(body)).unwrap().into_response()
}

/// Decode, resize to `width` (preserving aspect), and re-encode. Returns the
/// encoded bytes + content-type, or `None` if the input isn't a decodable image.
fn optimize_bytes(bytes: &[u8], width: u32, quality: u8, accept_webp: bool, formats: &[String]) -> Option<(Vec<u8>, &'static str)> {
    use image::imageops::FilterType;
    let img = image::load_from_memory(bytes).ok()?;
    let resized = if img.width() > width {
        let h = ((img.height() as u64 * width as u64) / img.width().max(1) as u64).max(1) as u32;
        img.resize(width, h, FilterType::Lanczos3)
    } else {
        img
    };

    // Prefer WebP when the client accepts it and config permits (image 0.25's
    // WebP encoder is lossless; fall back to JPEG/PNG on any error).
    let want_webp = accept_webp && (formats.is_empty() || formats.iter().any(|f| f == "image/webp"));
    if want_webp {
        let mut buf = std::io::Cursor::new(Vec::new());
        if resized.write_to(&mut buf, image::ImageFormat::WebP).is_ok() {
            return Some((buf.into_inner(), "image/webp"));
        }
    }
    if resized.color().has_alpha() {
        let mut buf = std::io::Cursor::new(Vec::new());
        resized.write_to(&mut buf, image::ImageFormat::Png).ok()?;
        Some((buf.into_inner(), "image/png"))
    } else {
        use image::ImageEncoder;
        let mut buf = Vec::new();
        let rgb = resized.to_rgb8();
        image::codecs::jpeg::JpegEncoder::new_with_quality(&mut buf, quality)
            .write_image(rgb.as_raw(), rgb.width(), rgb.height(), image::ExtendedColorType::Rgb8)
            .ok()?;
        Some((buf, "image/jpeg"))
    }
}

/// Minimal `application/x-www-form-urlencoded` query parser with percent-decode.
fn parse_query(q: &str) -> Vec<(String, String)> {
    q.split('&')
        .filter(|s| !s.is_empty())
        .map(|pair| {
            let (k, v) = pair.split_once('=').unwrap_or((pair, ""));
            (pct_decode(k), pct_decode(v))
        })
        .collect()
}

fn pct_decode(s: &str) -> String {
    let b = s.replace('+', " ");
    let bytes = b.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' && i + 2 < bytes.len() {
            let hi = (bytes[i + 1] as char).to_digit(16);
            let lo = (bytes[i + 2] as char).to_digit(16);
            if let (Some(h), Some(l)) = (hi, lo) {
                out.push((h * 16 + l) as u8);
                i += 3;
                continue;
            }
        }
        out.push(bytes[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

/// Is a remote image URL permitted by `images.remotePatterns` / `images.domains`?
fn remote_allowed(cfg: &fluid_core::ImagesConfig, url: &str) -> bool {
    // Parse scheme://host[:port]/path?query without a url crate.
    let after = url.splitn(2, "://").nth(1).unwrap_or("");
    let (authority, rest) = after.split_once('/').map(|(a, r)| (a, format!("/{r}"))).unwrap_or((after, "/".to_string()));
    let (host, port) = authority.split_once(':').map(|(h, p)| (h, Some(p))).unwrap_or((authority, None));
    let (pathname, search) = rest.split_once('?').map(|(p, s)| (p.to_string(), format!("?{s}"))).unwrap_or((rest.clone(), String::new()));
    let scheme = url.split("://").next().unwrap_or("");

    if cfg.domains.iter().any(|d| d == host) {
        return true;
    }
    cfg.remote_patterns.iter().any(|p| {
        p.protocol.as_deref().map(|pr| pr == scheme).unwrap_or(true)
            && host_matches(&p.hostname, host)
            && p.port.as_deref().map(|pt| pt.is_empty() || Some(pt) == port).unwrap_or(true)
            && p.pathname.as_deref().map(|pn| pattern_matches(pn, &pathname)).unwrap_or(true)
            && p.search.as_deref().map(|s| s.is_empty() || s == search).unwrap_or(true)
    })
}

fn local_allowed(cfg: &fluid_core::ImagesConfig, url: &str) -> bool {
    let (pathname, search) = url.split_once('?').map(|(p, s)| (p.to_string(), format!("?{s}"))).unwrap_or((url.to_string(), String::new()));
    cfg.local_patterns.iter().any(|p| {
        p.pathname.as_deref().map(|pn| pattern_matches(pn, &pathname)).unwrap_or(true)
            && p.search.as_deref().map(|s| s.is_empty() || s == search).unwrap_or(true)
    })
}

/// Hostname match supporting a single leading `**.` (any subdepth) or `*.`
/// (one label) wildcard, à la Next.js remotePatterns.
fn host_matches(pattern: &str, host: &str) -> bool {
    if let Some(suffix) = pattern.strip_prefix("**.") {
        host == suffix || host.ends_with(&format!(".{suffix}"))
    } else if let Some(suffix) = pattern.strip_prefix("*.") {
        host.strip_suffix(suffix).map(|p| p.ends_with('.') && !p[..p.len() - 1].contains('.')).unwrap_or(false)
    } else {
        pattern == host
    }
}

/// Match a remotePattern `pathname` (supports a trailing `/**` and a `^...$`
/// regex-ish form via simple prefix/glob) against a path. Best-effort.
fn pattern_matches(pattern: &str, value: &str) -> bool {
    // Treat an anchored regex like `^/account123/.*$` as a prefix on the literal
    // segment before `.*`.
    let pat = pattern.trim_start_matches('^').trim_end_matches('$');
    if let Some(prefix) = pat.strip_suffix(".*") {
        return value.starts_with(prefix);
    }
    if let Some(prefix) = pat.strip_suffix("/**") {
        return value == prefix || value.starts_with(&format!("{prefix}/"));
    }
    if let Some(prefix) = pat.strip_suffix("/*") {
        return value.strip_prefix(&format!("{prefix}/")).map(|r| !r.contains('/')).unwrap_or(false);
    }
    pat == value
}

async fn proxy_function(
    gw: &Arc<Gateway>,
    dep: &Deployment,
    name: &str,
    method: &Method,
    path_q: &str,
    headers: &HeaderMap,
    body: Bytes,
) -> Response {
    let key = func_key(dep.id.as_str(), name);

    // Collect forwardable request headers once.
    let hvec: Vec<(String, String)> = headers
        .iter()
        .filter(|(k, _)| {
            let n = k.as_str();
            n != "connection" && n != "content-length" && n != "host"
        })
        .filter_map(|(k, v)| v.to_str().ok().map(|s| (k.as_str().to_string(), s.to_string())))
        .collect();

    // Per-function max duration (Vercel default 300s) — bounds the whole
    // invocation; on timeout we return 504 without affecting other requests
    // sharing the instance (error isolation).
    let max_dur = Duration::from_secs(gw.fluid.max_duration_secs(&key).unwrap_or(300).max(1));

    const MAX_REROUTES: usize = 3;
    let mut last_err = String::from("unknown");
    for attempt in 0..MAX_REROUTES {
        let lease = match gw.fluid.lease(&key).await {
            Ok(l) => l,
            Err(e) => {
                // Structured failure (#18): classify, return a STABLE public code +
                // correct status — never leak the internal error to the caller.
                let es = e.to_string();
                let class = classify_lease_error(&es);
                warn!(func = %key, error = %es, code = class.code(), "lease failed");
                let status = StatusCode::from_u16(class.status()).unwrap_or(StatusCode::SERVICE_UNAVAILABLE);
                let mut resp = (status, class.code()).into_response();
                resp.headers_mut().insert("x-hive-error", HeaderValue::from_static(class.code()));
                return resp;
            }
        };
        let cell = lease.cell_id().clone();
        let ep = lease.endpoint.clone();

        let (client, reused) = match gw.tunnel_for(&cell, &ep).await {
            Ok(c) => c,
            Err(e) => {
                last_err = e.to_string();
                tracing::debug!(cell = %cell, attempt, error = %last_err, "tunnel connect failed");
                drop(lease);
                gw.fluid.mark_dead(&key, &cell).await;
                gw.drop_tunnel(&cell).await;
                continue;
            }
        };

        tracing::debug!(cell = %cell, reused, attempt, "dispatching request over tunnel");
        let req_fut = client.request(method.as_str(), path_q, hvec.clone(), &body);
        match tokio::time::timeout(max_dur, req_fut).await {
            Err(_) => {
                // Exceeded max duration — 504, do not reroute (the instance is
                // fine; only this invocation is over budget).
                drop(lease);
                return (StatusCode::GATEWAY_TIMEOUT, "FUNCTION_INVOCATION_TIMEOUT").into_response();
            }
            Ok(Ok(resp)) => {
                tracing::debug!(cell = %cell, status = resp.status, "got response head");
                return build_response(lease, cell, reused, attempt, resp).await;
            }
            Ok(Err(e)) => {
                last_err = e.to_string();
                tracing::debug!(cell = %cell, reused, attempt, error = %last_err, "request failed");
                drop(lease);
                // Tunnel-level failure: if it's closed the instance is gone.
                if client.is_closed() {
                    gw.fluid.mark_dead(&key, &cell).await;
                    gw.drop_tunnel(&cell).await;
                }
                // else: nack/overload — just reroute to another instance.
            }
        }
    }
    // Reroute budget exhausted — runtime tunnel kept failing. Public code only;
    // the internal `last_err` (tunnel internals) stays in the log (#18).
    warn!(func = %key, error = %last_err, "upstream failed after reroute budget");
    let class = fluid_core::FailureClass::RuntimeTunnelFailed;
    let mut resp = (StatusCode::from_u16(class.status()).unwrap_or(StatusCode::BAD_GATEWAY), class.code()).into_response();
    resp.headers_mut().insert("x-hive-error", HeaderValue::from_static(class.code()));
    resp
}

/// Classify a `Fluid::lease` error into a stable public [`FailureClass`] (#18).
/// A tenant hitting its cross-pool instance quota is a 429 (back off, you're
/// throttled); any other lease failure (concurrency saturation, cold-start cap,
/// provisioning failure) is a 503 capacity problem. Coupled to the `NackReason`
/// Debug name surfaced by `fluid-compute`'s `bail!("... ({reason:?})")` — the
/// `classify_lease_error_*` tests lock that contract so a format change can't
/// silently downgrade quota throttles to generic capacity errors.
fn classify_lease_error(es: &str) -> fluid_core::FailureClass {
    if es.contains("TenantQuota") {
        fluid_core::FailureClass::TenantThrottled
    } else {
        fluid_core::FailureClass::CapacityExhausted
    }
}

/// Turn a tunnel response into an axum response.
///
/// Normal responses are **buffered** and returned with a correct content-length
/// (always terminates cleanly). Streaming responses (`text/event-stream`) are
/// passed through chunked. The lease is held for the body (and any `waitUntil`
/// window) before the instance slot is released.
async fn build_response(
    lease: fluid_compute::Lease,
    cell: CellId,
    reused: bool,
    attempt: usize,
    mut resp: fluid_tunnel::TunnelResponse,
) -> Response {
    let mut hdrs = HeaderMap::new();
    // Stream incrementally for ANY response the function didn't declare a fixed
    // length for — matching Vercel streaming-functions behavior. That covers SSE
    // (text/event-stream), React Server Component streaming (text/x-component,
    // chunked HTML), and AI-SDK/ReadableStream responses (chunked, no
    // content-length). A response WITH a content-length is a finished, sized body
    // → buffer it (sized, clean termination), exactly as before.
    let mut has_content_length = false;
    let mut forced_stream = false;
    for (k, v) in &resp.headers {
        let kl = k.to_ascii_lowercase();
        if kl == "content-length" {
            has_content_length = true;
            continue;
        }
        if kl == "transfer-encoding" {
            if v.to_ascii_lowercase().contains("chunked") {
                forced_stream = true;
            }
            continue;
        }
        if kl == "connection" {
            continue;
        }
        let vl = v.to_ascii_lowercase();
        if kl == "content-type" && (vl.contains("event-stream") || vl.contains("x-component") || vl.contains("stream")) {
            forced_stream = true;
        }
        if let (Ok(name), Ok(val)) = (
            HeaderName::from_bytes(k.as_bytes()),
            HeaderValue::from_str(v),
        ) {
            hdrs.append(name, val);
        }
    }
    let is_stream = forced_stream || !has_content_length;
    hdrs.insert(
        HeaderName::from_static("x-fluid-instance"),
        HeaderValue::from_str(&cell.to_string()).unwrap_or(HeaderValue::from_static("?")),
    );
    hdrs.insert(
        HeaderName::from_static("x-fluid-reused"),
        HeaderValue::from_static(if reused { "true" } else { "false" }),
    );
    if attempt > 0 {
        if let Ok(v) = HeaderValue::from_str(&attempt.to_string()) {
            hdrs.insert(HeaderName::from_static("x-fluid-rerouted"), v);
        }
    }

    let status = StatusCode::from_u16(resp.status).unwrap_or(StatusCode::BAD_GATEWAY);
    let wait_until_ms = resp.wait_until_ms;

    // Helper to release the lease, honoring waitUntil.
    let release = move |lease: fluid_compute::Lease| {
        if wait_until_ms > 0 {
            tokio::spawn(async move {
                tokio::time::sleep(Duration::from_millis(wait_until_ms)).await;
                drop(lease);
            });
        } else {
            drop(lease);
        }
    };

    if is_stream {
        // Pass-through streaming (chunked) for event streams.
        let st = BodyState {
            body: resp.body,
            lease: Some(lease),
            wait_until_ms,
        };
        let body_stream = futures::stream::unfold(st, |mut st| async move {
            match st.body.recv().await {
                Some(chunk) => Some((Ok::<_, std::io::Error>(chunk), st)),
                None => {
                    if let Some(lease) = st.lease.take() {
                        if st.wait_until_ms > 0 {
                            let w = st.wait_until_ms;
                            tokio::spawn(async move {
                                tokio::time::sleep(Duration::from_millis(w)).await;
                                drop(lease);
                            });
                        } else {
                            drop(lease);
                        }
                    }
                    None
                }
            }
        });
        let mut out = Response::new(Body::from_stream(body_stream));
        *out.status_mut() = status;
        *out.headers_mut() = hdrs;
        return out;
    }

    // Buffered path: collect the whole body, return a sized response. Bounded by
    // a max-duration so a stalled upstream becomes a 504 rather than hanging.
    let mut buf = Vec::new();
    let drained = tokio::time::timeout(Duration::from_secs(30), async {
        while let Some(chunk) = resp.body.recv().await {
            buf.extend_from_slice(&chunk);
        }
    })
    .await;
    release(lease);
    if drained.is_err() {
        return (StatusCode::GATEWAY_TIMEOUT, "upstream timed out").into_response();
    }
    let mut out = (status, buf).into_response();
    *out.headers_mut() = hdrs;
    out
}

struct BodyState {
    body: tokio::sync::mpsc::UnboundedReceiver<Bytes>,
    lease: Option<fluid_compute::Lease>,
    wait_until_ms: u64,
}

/// Build a `DeploymentInfo` view from a stored deployment.
/// DNS-safe subdomain slug: lowercase, only `[a-z0-9-]`, no leading/trailing or
/// repeated dashes. Used to build branch/commit alias labels from arbitrary
/// branch names (e.g. `feature/Login` -> `feature-login`).
fn slug(s: &str) -> String {
    let mapped: String = s
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() { c.to_ascii_lowercase() } else { '-' })
        .collect();
    mapped.split('-').filter(|p| !p.is_empty()).collect::<Vec<_>>().join("-")
}

/// Immutable commit URL label: `<project>-<shortsha>` (Vercel's per-commit URL).
fn commit_alias(project: &str, commit: &str) -> String {
    let short: String = commit.chars().take(7).collect();
    format!("{}-{}", slug(project), slug(&short))
}

/// Branch URL label: `<project>-git-<branch>` — always points at the latest
/// deployment on that branch (Vercel's per-branch URL).
fn branch_alias(project: &str, branch: &str) -> String {
    format!("{}-git-{}", slug(project), slug(branch))
}

/// Point `key` at deployment `id` only if `id` is "newer" than whatever the alias
/// currently resolves to — ranked by (production, created_at). Keeps branch/commit
/// aliases tracking the right deployment even when records restore out of order.
fn set_alias_if_newer(st: &mut GwState, key: &str, id: &DeploymentId) {
    let Some(cand) = st.deployments.get(id).map(|d| (d.production, d.created_at_ms)) else {
        return;
    };
    let win = match st.aliases.get(key).and_then(|cur| st.deployments.get(cur)) {
        None => true,
        Some(ex) => cand > (ex.production, ex.created_at_ms),
    };
    if win {
        st.aliases.insert(key.to_string(), id.clone());
    }
}

/// Insert the immutable per-deployment alias plus the commit + branch URL aliases
/// for a deployment already present in `st.deployments`.
fn insert_deploy_aliases(st: &mut GwState, id: &DeploymentId) {
    st.aliases.insert(id.as_str().to_string(), id.clone());
    let meta = st.deployments.get(id).map(|d| (d.project.clone(), d.git.clone()));
    if let Some((project, Some(g))) = meta {
        if !g.commit.is_empty() {
            set_alias_if_newer(st, &commit_alias(&project, &g.commit), id);
        }
        if !g.branch.is_empty() {
            set_alias_if_newer(st, &branch_alias(&project, &g.branch), id);
        }
    }
}

fn view_of(d: &Deployment) -> DeploymentInfo {
    let has_static = d.manifest.static_dir.is_some();
    let has_fn = !d.manifest.functions.is_empty();
    let kind = match (has_static, has_fn) {
        (true, true) => "fullstack",
        (false, true) => "function",
        _ => "static",
    };
    // Vercel's 3 URL types, surfaced so the dashboard can link each deployment to
    // its own immutable commit URL + branch URL (not just the production domain).
    let commit_alias = d
        .git
        .as_ref()
        .filter(|g| !g.commit.is_empty())
        .map(|g| format!("{}.localhost", commit_alias(&d.project, &g.commit)))
        .unwrap_or_default();
    let branch_alias = d
        .git
        .as_ref()
        .filter(|g| !g.branch.is_empty())
        .map(|g| format!("{}.localhost", branch_alias(&d.project, &g.branch)))
        .unwrap_or_default();
    DeploymentInfo {
        id: d.id.clone(),
        project: d.project.clone(),
        functions: d.manifest.functions.iter().map(|f| f.name.clone()).collect(),
        created_at_ms: d.created_at_ms,
        alias: format!("{}.localhost", d.project),
        commit_alias,
        branch_alias,
        id_alias: format!("{}.localhost", d.id.as_str()),
        // Immutable build environment (a superseded prod build stays "production").
        target: if d.target.is_empty() {
            if d.production { "production".into() } else { "preview".into() }
        } else {
            d.target.clone()
        },
        state: d.state,
        creator: d.creator.clone(),
        git: d.git.clone(),
        production: d.production,
        kind: kind.to_string(),
        features: fluid_core::DeploymentFeatures {
            redirects: d.manifest.redirects.len(),
            rewrites: d.manifest.rewrites.len(),
            middleware: d.manifest.middleware.is_some(),
            edge_functions: d.manifest.edge_function_count(),
            serverless_functions: d.manifest.functions.iter().filter(|f| f.runtime != "edge").count(),
        },
        tenant: d.tenant.clone(),
    }
}

fn is_within(base: &Path, candidate: &Path) -> bool {
    // `candidate` is `base.join(rel)`; if it stays under `base` with no `..`
    // components, it's safe.
    match candidate.strip_prefix(base) {
        Ok(rest) => !rest
            .components()
            .any(|c| matches!(c, std::path::Component::ParentDir)),
        Err(_) => false,
    }
}

fn content_type(file: &Path) -> &'static str {
    match file.extension().and_then(|e| e.to_str()) {
        Some("html") | Some("htm") => "text/html; charset=utf-8",
        Some("css") => "text/css",
        Some("js") | Some("mjs") => "text/javascript",
        Some("json") => "application/json",
        Some("svg") => "image/svg+xml",
        Some("png") => "image/png",
        Some("jpg") | Some("jpeg") => "image/jpeg",
        Some("gif") => "image/gif",
        Some("ico") => "image/x-icon",
        Some("txt") => "text/plain; charset=utf-8",
        Some("wasm") => "application/wasm",
        _ => "application/octet-stream",
    }
}

#[cfg(test)]
mod route_policy_tests {
    use super::*;
    use fluid_core::{Manifest, RouteClass, RoutePolicy};

    fn dep_with(policies: Vec<RoutePolicy>) -> Deployment {
        Deployment {
            id: DeploymentId::from("dpl-test".to_string()),
            project: "p".into(),
            root: PathBuf::from("/tmp"),
            manifest: Manifest { project: "p".into(), route_policies: policies, ..Default::default() },
            created_at_ms: 0,
            state: fluid_core::DeployState::Ready,
            creator: String::new(),
            git: None,
            production: true,
            target: "production".into(),
            tenant: String::new(),
        }
    }

    fn resp(status: StatusCode, cache: Option<&str>) -> Response {
        let mut b = Response::builder().status(status);
        if let Some(c) = cache {
            b = b.header(header::CACHE_CONTROL, c);
        }
        b.body(Body::empty()).unwrap().into_response()
    }

    fn cc(r: &Response) -> Option<String> {
        r.headers().get(header::CACHE_CONTROL).map(|v| v.to_str().unwrap().to_string())
    }

    #[test]
    fn no_policies_is_byte_identical_noop() {
        let dep = dep_with(vec![]);
        let r = apply_route_policy(resp(StatusCode::OK, None), &dep, "/anything");
        assert!(cc(&r).is_none());
        assert!(!r.headers().contains_key("x-hive-route-class"));
    }

    #[test]
    fn isr_route_gets_synthesized_cache_and_class_header() {
        let dep = dep_with(vec![RoutePolicy { pattern: "/blog/[slug]".into(), class: RouteClass::Isr, revalidate: Some(120) }]);
        let r = apply_route_policy(resp(StatusCode::OK, None), &dep, "/blog/hello");
        assert_eq!(cc(&r).as_deref(), Some("public, s-maxage=120, stale-while-revalidate"));
        assert_eq!(r.headers().get("x-hive-route-class").unwrap(), "isr");
    }

    #[test]
    fn origin_cache_control_is_never_overridden() {
        let dep = dep_with(vec![RoutePolicy { pattern: "/blog/[slug]".into(), class: RouteClass::Isr, revalidate: Some(120) }]);
        let r = apply_route_policy(resp(StatusCode::OK, Some("private, no-store")), &dep, "/blog/hello");
        assert_eq!(cc(&r).as_deref(), Some("private, no-store"), "app intent wins");
        // class header is still tagged for observability.
        assert_eq!(r.headers().get("x-hive-route-class").unwrap(), "isr");
    }

    #[test]
    fn dynamic_route_tagged_but_no_synthetic_cache() {
        let dep = dep_with(vec![RoutePolicy { pattern: "/api/claw".into(), class: RouteClass::ApiNode, revalidate: None }]);
        let r = apply_route_policy(resp(StatusCode::OK, None), &dep, "/api/claw");
        assert!(cc(&r).is_none(), "dynamic defers to origin");
        assert_eq!(r.headers().get("x-hive-route-class").unwrap(), "api_node");
    }

    #[test]
    fn non_success_status_not_cached() {
        let dep = dep_with(vec![RoutePolicy { pattern: "/blog/[slug]".into(), class: RouteClass::Isr, revalidate: Some(120) }]);
        let r = apply_route_policy(resp(StatusCode::INTERNAL_SERVER_ERROR, None), &dep, "/blog/hello");
        assert!(cc(&r).is_none(), "errors are not cached");
    }
}

#[cfg(test)]
mod failure_class_tests {
    use super::*;
    use fluid_core::FailureClass;

    #[test]
    fn classify_lease_error_maps_quota_and_capacity() {
        // Quota breach -> 429 throttle.
        let q = classify_lease_error("function 'app:fn' saturated (TenantQuota)");
        assert_eq!(q, FailureClass::TenantThrottled);
        assert_eq!(q.status(), 429);
        assert_eq!(q.code(), "TENANT_THROTTLED");
        // Concurrency saturation / cold-start cap / anything else -> 503 capacity.
        for es in [
            "function 'app:fn' saturated (ConcurrencyLimit)",
            "function 'app:fn' saturated (ColdStartCap)",
            "cold-start coalesce timed out",
            "provision failed: backend stub",
        ] {
            let c = classify_lease_error(es);
            assert_eq!(c, FailureClass::CapacityExhausted, "for {es}");
            assert_eq!(c.status(), 503);
            assert_eq!(c.code(), "CAPACITY_EXHAUSTED");
        }
    }

    #[test]
    fn classify_lease_error_matches_fluid_bail_format() {
        // Lock the cross-crate contract: the string fluid-compute actually bails
        // with on a tenant-quota NACK must classify as TenantThrottled. If
        // fluid-compute changes its Debug/bail format, this fails loudly here
        // instead of silently downgrading throttles to 503 in production.
        let reason = fluid_compute::NackReason::TenantQuota;
        let bail = format!("function 'app:fn' saturated ({reason:?})");
        assert!(bail.contains("TenantQuota"), "fluid bail string was: {bail}");
        assert_eq!(classify_lease_error(&bail), FailureClass::TenantThrottled);
    }
}

#[cfg(test)]
mod image_tests {
    use super::*;

    #[test]
    fn pct_decode_and_query() {
        let q = parse_query("url=%2Fa%2Fb.png&w=640&q=75");
        assert_eq!(q[0], ("url".to_string(), "/a/b.png".to_string()));
        assert_eq!(q[1], ("w".to_string(), "640".to_string()));
    }

    #[test]
    fn host_and_pattern_matching() {
        assert!(host_matches("example.com", "example.com"));
        assert!(!host_matches("example.com", "evil.com"));
        assert!(host_matches("**.example.com", "cdn.images.example.com"));
        assert!(host_matches("*.example.com", "cdn.example.com"));
        assert!(!host_matches("*.example.com", "a.b.example.com"));
        assert!(pattern_matches("^/account123/.*$", "/account123/pic.png"));
        assert!(!pattern_matches("^/account123/.*$", "/other/pic.png"));
        assert!(pattern_matches("/imgs/**", "/imgs/a/b.png"));
        assert!(pattern_matches("/imgs/*", "/imgs/a.png"));
        assert!(!pattern_matches("/imgs/*", "/imgs/a/b.png"));
    }

    #[test]
    fn optimize_resizes_and_encodes() {
        // Build a 100x50 opaque RGB image, encode to PNG, then optimize to w=40.
        let img = image::DynamicImage::ImageRgb8(image::RgbImage::new(100, 50));
        let mut src = std::io::Cursor::new(Vec::new());
        img.write_to(&mut src, image::ImageFormat::Png).unwrap();
        let (out, ctype) = optimize_bytes(src.get_ref(), 40, 75, false, &[]).expect("optimized");
        // Opaque -> JPEG, and the decoded result is 40px wide.
        assert_eq!(ctype, "image/jpeg");
        let decoded = image::load_from_memory(&out).unwrap();
        assert_eq!(decoded.width(), 40);
        assert_eq!(decoded.height(), 20);
    }

    #[test]
    fn static_cache_classification() {
        assert_eq!(static_cache_control("/_next/static/chunks/main.js"), "public, max-age=31536000, immutable");
        assert_eq!(static_cache_control("/assets/index-4f3a9c2b.js"), "public, max-age=31536000, immutable");
        assert_eq!(static_cache_control("/main.1a2b3c4d.css"), "public, max-age=31536000, immutable");
        // Non-hashed assets + HTML get the safe revalidating default.
        assert_eq!(static_cache_control("/index.html"), "public, max-age=0, must-revalidate");
        assert_eq!(static_cache_control("/styles.css"), "public, max-age=0, must-revalidate");
        assert_eq!(static_cache_control("/bootstrap5.css"), "public, max-age=0, must-revalidate"); // not a hex hash
        assert_eq!(static_cache_control("/documentation.html"), "public, max-age=0, must-revalidate");
        assert!(!is_hashed_asset("react-dom.js"));
        assert!(is_hashed_asset("index-4f3a9c2b.js"));
    }

    #[test]
    fn remote_allow_list() {
        let cfg = fluid_core::ImagesConfig {
            remote_patterns: vec![fluid_core::RemotePattern {
                protocol: Some("https".into()),
                hostname: "example.com".into(),
                port: None,
                pathname: Some("^/a/.*$".into()),
                search: None,
            }],
            ..Default::default()
        };
        assert!(remote_allowed(&cfg, "https://example.com/a/pic.png"));
        assert!(!remote_allowed(&cfg, "https://example.com/b/pic.png"));
        assert!(!remote_allowed(&cfg, "http://example.com/a/pic.png")); // wrong scheme
        assert!(!remote_allowed(&cfg, "https://evil.com/a/pic.png"));
    }
}
